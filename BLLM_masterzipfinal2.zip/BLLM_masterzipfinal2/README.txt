BLLM master zip

BLLM: The Entropy Cost of Sound Self-Improvement and a Typed Crossing Network
Tested on Five Open Problems, by Deep Bhattacharjee and Ushashi Bhattacharya.

D7-v2.0.0/    the paper repository at release v2.0.0: the paper PDF, the tex zip
              and the arXiv tarball in dist/, the REVTeX source in BLLM/paper,
              the Lean 4 project (59 theorems) in BLLM/lean and the checks
              (55,271) in BLLM/checks. Zenodo: doi:10.5281/zenodo.23455866
              (all versions doi:10.5281/zenodo.23449604).
eBLLM-v2.0.0/ the package eBLLM 2.0.0: the crossing network, memory, agents,
              the five-problem benchmark and the logs of every run.
              Zenodo: doi:10.5281/zenodo.23455686 (all versions
              doi:10.5281/zenodo.23286641).
hexagon/      AI_PROVENANCE_BeyondTheLLM.md and HEXAGON_FORM.md; with
              D7-v2.0.0/dist/BeyondTheLLM_final2.pdf and
              BeyondTheLLM_final2-tex.zip they make the Hexagon upload.

To rerun the paper's checks: bash D7-v2.0.0/BLLM/checks/run_all.sh
To rerun the package's checks: cd eBLLM-v2.0.0 && checks/run_all.sh
None of the five benchmark problems is solved.
