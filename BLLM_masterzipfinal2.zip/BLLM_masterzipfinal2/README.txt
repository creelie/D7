BLLM master zip

BLLM: The Entropy Cost of Sound Self-Improvement and a Typed Crossing Network
Tested on Five Open Problems, by Deep Bhattacharjee and Ushashi Bhattacharya.

D7-v2.0.1/    the paper repository at release v2.0.1: the paper PDF, the tex zip
              and the arXiv tarball in dist/, the REVTeX source in BLLM/paper,
              the Lean 4 project (59 theorems) in BLLM/lean and the checks
              (55,271) in BLLM/checks. Zenodo: doi:10.5281/zenodo.23456196
              (all versions doi:10.5281/zenodo.23449604).
eBLLM-v2.0.1/ the package eBLLM 2.0.1: the crossing network, memory, agents,
              the five-problem benchmark and the logs of every run.
              Zenodo: doi:10.5281/zenodo.23456124 (all versions
              doi:10.5281/zenodo.23286641).
hexagon/      AI_PROVENANCE_BeyondTheLLM.md and HEXAGON_FORM.md; with
              D7-v2.0.1/dist/BeyondTheLLM_final2.pdf and
              BeyondTheLLM_final2-tex.zip they make the Hexagon upload.

Version 2.0.1 corrects the value of f(20) in Erdos problem 1183 to 12: the
level colouring 000101100111001011100 gives the upper bound, and Theorem 7.6
of the fifth version of Bhattacharjee, Mandal and Bhattacharya
(doi:10.5281/zenodo.23374973) gives the lower bound.

To rerun the paper's checks: bash D7-v2.0.1/BLLM/checks/run_all.sh
To rerun the package's checks: cd eBLLM-v2.0.1 && checks/run_all.sh
None of the five benchmark problems is solved.
