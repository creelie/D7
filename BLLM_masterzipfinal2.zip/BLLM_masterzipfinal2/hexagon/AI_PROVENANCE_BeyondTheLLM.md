# AI provenance: BLLM: The Entropy Cost of Sound Self-Improvement and a Typed Crossing Network Tested on Five Open Problems

Authors: Deep Bhattacharjee (corresponding author, ORCID 0000-0003-0466-750X;
formerly EGSPL, Bhubaneswar, Odisha 751030, India, and formerly University of
Calcutta, Senate House, 87/1 College Street, Kolkata 700073, West Bengal,
India) and Ushashi Bhattacharya (ORCID 0009-0002-2254-3914; formerly National
Taiwan University, Taipei 106319, Taiwan).

- Paper: https://github.com/creelie/D7/blob/main/preprintBeyondTheLLM/BeyondTheLLM.pdf
- Lean formalisation and code of the paper: folder BLLM of https://github.com/creelie/D7, release v2.0.1, Zenodo https://doi.org/10.5281/zenodo.23456196 (all versions https://doi.org/10.5281/zenodo.23449604)
- Package eBLLM 2.0.1 (benchmark, crossing network, memory, agents, Erdős 1183 searches, logs of every run): https://github.com/creelie/eBLLM, Zenodo https://doi.org/10.5281/zenodo.23456124 (all versions https://doi.org/10.5281/zenodo.23286641)

## Result

Inside a model of randomized checks the paper computes the least cost of
soundness: the entropy law (Theorem A), Huffman schedules (Theorem B), the
Rényi law (Theorem C), the chain law (Theorem F) and step-versus-outcome
checking (Theorem VII.2), the singularity criterion Σ a_n log(1/a_n) < ∞
(Theorem D), the branching takeoff (Theorem E), the online law (Theorem G),
subagents (Theorem H) and cascades (Theorem X.1), and the gap law (Theorem I): a
proposer needs at least e^{H_{1/2}(π)} proposals, attained only by
square-root sampling, and language models need 1.5 to 4.3 times this.

It then measures a typed crossing network with shared memory on five open
problems (the Yang–Mills mass gap, the Hodge conjecture, the standard
conjecture of Lefschetz type, Chowla's conjecture and Erdős problem 1183):

- Typed crossing reached in every run a composite accepting a lattice mass
  gap for four-dimensional SU(2) on β_W < 1/3, which no random or
  type-filtered run reached. The composite was first proposed by the language
  model, so the network reproduces the step. The step, m ≥ −log(3β_W), is
  proved in the paper (Theorem XV.4) and has not been refereed; no forest
  gauge fixing goes past 1/3.
- Hebbian boosters add nothing (12 and 14 of 200 runs against 21).
- Shared memory reaches the same plateau with 46.4 checks against 95.2.
- Five agents hold 24 survivors for 250 checks against 27 for 797 from a
  single loop; no survivor of either reaches a target point.
- Of 38 transfers of a barrier-breaking pattern, none closes, 7 are partial
  and 31 fail.
- In Erdős problem 1183 a reduction of level colourings to weighted posets
  (Lemma XV.1) gives the upper bounds that, with the known lower bounds,
  determine f(n) for n ≤ 20 (Theorem XV.2), with f(20) = 12. The lower bound
  for odd n ≥ 11 is the OpenRefute Lean theorem, and f(20) ≥ 12 is Theorem 7.6
  of the fifth version of Bhattacharjee, Mandal and Bhattacharya
  (https://doi.org/10.5281/zenodo.23374973), whose proof ends in a finite
  check; both are credited.

## Who did what

Deep Bhattacharjee chose the problems, directed the work, set the format and
ran the computations. Claude (Anthropic), used through Claude Code under his
direction, produced the proofs, the Lean 4 formalisation, the checking
programs in Python, C, C++ and shell, the benchmark, the crossing network and
its controls, the figures, the LaTeX text and its reference list (every
reference was checked against the publisher's, Crossref's, zbMATH's or the
archive's record), and this file. No other AI system took part, apart from
the language models measured as proposers in the experiments. Claude is not
listed as a contributor.

## How the result is checked

- Lean 4 with Mathlib: fifty-nine theorems covering every finite inequality
  of the model (Appendix B), each depending only on propext,
  Classical.choice and Quot.sound; no sorry or added axiom.
- Independent Python, C and C++ programs: 55,271 checks, no failure.
- Erdős 1183: each colouring for n ≤ 10 checked by an exact C search and a
  separate SAT query; n = 11 also by both; n ≤ 20 by the weighted-poset
  search, cross-checked against the exact search on 150 colourings.
- Every measured number of the experiments is produced by the eBLLM 2.0.1
  package from fixed seeds; the logs are archived with it.

## What is not claimed

The paper does not claim that a BLLM proves the Hodge conjecture, the
Yang–Mills mass gap (the Clay problem) or any of the five problems; none is
solved. It does not claim f(n) = O(n). The β_W < 1/3 theorem is a lattice
result at strong coupling, not the continuum mass gap. The probabilistic
limit theorems are proved or cited in the text and are not formalised.
