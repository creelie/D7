# Hexagon submission fields

Title: BLLM: The Entropy Cost of Sound Self-Improvement and a Typed Crossing Network Tested on Five Open Problems

Abstract: We prove that certifying self-modifications of total cost $A$ with at most $\theta$ expected false acceptances costs $(A/\log\varepsilon^{-1})(H(p)+\log\theta^{-1})$ up to an additive $A$, that a sound infinite self-improvement of finite cost exists exactly when $\sum_{n}a_{n}\log(1/a_{n})$ converges, and that a proposer needs at least $e^{H_{1/2}(\pi)}$ proposals, a bound that language models miss by factors of $1.5$ to $4.3$. A typed crossing network with shared memory, run on five open problems including the Yang--Mills mass gap and the Hodge conjecture, reaches what its libraries can reach with half the checks, including a lattice mass gap for $\mathrm{SU}(2)$ on $\beta_{W}<\frac13$ that we prove; Hebbian boosters add nothing, and none of the five problems is solved.

Primary subject: cs.AI (Artificial Intelligence)
Cross-list subjects: cs.IT (Information Theory); cs.LG (Machine Learning); math.PR (Probability)
Tags: recursive self-improvement, verification, entropy, automated discovery
MSC2020: 68T05; 68T20; 94A17; 60J80

Contributor 1 (submitting): Deep Bhattacharjee; ORCID 0000-0003-0466-750X; affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; formerly, University of Calcutta, Senate House, 87/1 College Street, Kolkata 700073, West Bengal, India; itsdeep@live.com (second address d.bhattacharjee@erl-forschung.de)
Contributor 2: Ushashi Bhattacharya; ORCID 0009-0002-2254-3914; affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan; rai.bhattacharya.in@gmail.com
(No AI system is listed as a contributor.)

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: "Some parts, but not all" (change to "All parts" only after both authors have read every proof).

Provenance statement: The proofs, the text, the figures, the Lean 4 formalization, the benchmark and the C, C++, Python and shell programs were carried out by Deep Bhattacharjee with the help of AI assistance (Claude, Anthropic) in the Claude Code environment. In a model with independent runs, perfect completeness and schedules fixed in advance, the paper proves that the least cost of a sound schedule of randomized checks is an entropy (Theorem A), that Huffman codes give the exact optimum (Theorem B), that Renyi entropies govern checks of polynomial order (Theorem C), that a singular chain can be sound exactly when the entropy series of its check costs converges (Theorem D), that a branching takeoff needs linearly growing check strength (Theorem E), the chain law (Theorem F), the online law (Theorem G), the laws of subagents and cascades (Theorems H and X.1), and the gap law (Theorem I): a proposer needs at least exp(H_{1/2}(pi)) proposals. The experiments measure a typed crossing network with shared memory on five open problems: typed crossing reproduces a lattice mass gap for SU(2) on beta_W < 1/3 (Theorem XV.4, proved in the paper, not refereed, a strong-coupling lattice result and not the Clay problem), memory halves the checks, boosters add nothing, and none of the five problems is solved. Lemma XV.1 and Theorem XV.2 give the exact values of f(n) for Erdos problem 1183 for n <= 20, with f(20) = 12; the lower bound at n = 20 is Theorem 7.6 of the fifth version of Bhattacharjee, Mandal and Bhattacharya (doi:10.5281/zenodo.23374973), whose proof ends in a finite check. Every finite inequality is proved in Lean 4 with Mathlib in fifty-nine theorems that depend only on propext, Classical.choice and Quot.sound, with no sorry, native_decide or added axiom. The probabilistic limit theorems are proved or cited in the text and are not formalized. Independent Python, C and C++ programs run 55,271 checks with no failure; no statement rests on them. Both authors approved the final version.

Tools used: Anthropic - Claude (Claude Code); Lean community - Lean 4 (v4.33.0) with Mathlib; C; C++; Python; shell.
arXiv identifier: none (not posted on arXiv).
Formalization: https://github.com/creelie/D7/tree/main/BLLM/lean, release v2.0.1, https://doi.org/10.5281/zenodo.23456196 (all versions: https://doi.org/10.5281/zenodo.23449604); package eBLLM 2.0.1: https://github.com/creelie/eBLLM, https://doi.org/10.5281/zenodo.23456124 (all versions: https://doi.org/10.5281/zenodo.23286641)

Source files or ZIP: BeyondTheLLM_final2-tex.zip (the folder BeyondTheLLM_final2-tex/ with main.tex, sections/ and figures/ as PNG; compiles with latexmk -pdf main.tex, no BibTeX pass, all fonts embedded). Do not upload the Lean files or the programs here.
AI provenance files: AI_PROVENANCE_BeyondTheLLM.md
License: CC BY 4.0

Data availability (in the paper): LaTeX source, the Lean 4 formalization and the programs in the folder BLLM of https://github.com/creelie/D7, archived at Zenodo under doi:10.5281/zenodo.23449604 (all versions); the benchmark, crossing network and Erdos 1183 searches in version 2 of the package eBLLM, https://github.com/creelie/eBLLM, doi:10.5281/zenodo.23286641 (all versions); the folder preprintBeyondTheLLM holds the PDF only.
AI disclosure (in the paper, Data and code availability): Deep Bhattacharjee carried out the computations and the Lean, C, C++, Python and shell verifications with the help of AI assistance (Claude, Anthropic); both authors approved the final version. No separate AI declaration.
Funding: none. Competing interests: none.
Device folder: D:\Hexagon\14 BeyondTheLLM.
Upload order: BeyondTheLLM_final2.pdf, BeyondTheLLM_final2-tex.zip, AI_PROVENANCE_BeyondTheLLM.md, HEXAGON_FORM.md. The arXiv tarball BeyondTheLLM_final2-arxiv.tar.gz is for arXiv only.
